/*
Simon Van Braeckel
 */

package datatransferobjects;

public interface NameIdDTO {
    int getId();

    String getName();
}
