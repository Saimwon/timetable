/*
Van Braeckel Simon
 */

package database.DTO;

public class DTO {
}
