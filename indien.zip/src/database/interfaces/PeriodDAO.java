/*
Van Braeckel Simon
 */

package database.interfaces;

import java.util.List;

public interface PeriodDAO {
    public List<String> getStartTimes();
}
