/*
Van Braeckel Simon
 */

package databasemanipulation.dataaccessobjects.dataccessinterfaces;

import java.util.List;

public interface PeriodDAO {
    List<String> getStartTimes();
}
