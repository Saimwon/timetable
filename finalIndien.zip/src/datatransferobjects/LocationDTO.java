/*
Van Braeckel Simon
 */

package datatransferobjects;

public class LocationDTO extends SimpleDTO {
    public LocationDTO(int id, String name){
        super(id, name);
    }

    public LocationDTO(){
        super();
    }
}
